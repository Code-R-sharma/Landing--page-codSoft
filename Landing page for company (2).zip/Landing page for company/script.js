document.getElementById('registerBtn').addEventListener('click', function() {
    window.location.href = 'register.html';

    const links = document.querySelectorAll('.nav-link');

    // Add click event listener to each link
    links.forEach(link => {
        link.addEventListener('click', function() {
            // Remove 'selected' class from all links
            links.forEach(link => link.classList.remove('selected'));

            // Add 'selected' class to the clicked link
            this.classList.add('selected');
        });
    });
    
});